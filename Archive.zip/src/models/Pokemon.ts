class Pokemon {
  name: string;
  imageUrl: string;
  firstType: string;
  firstMove: string;
  lastMove: string;

  constructor(
    name: string,
    number: number,
    firstType: string,
    firstMove: string,
    lastMove: string,
  ) {
    this.name = name;
    this.imageUrl = `https://unpkg.com/pokeapi-sprites@2.0.2/sprites/pokemon/other/dream-world/${number}.svg`;
    this.firstType = firstType;
    this.firstMove = firstMove;
    this.lastMove = lastMove;
  }
}

export default Pokemon;
