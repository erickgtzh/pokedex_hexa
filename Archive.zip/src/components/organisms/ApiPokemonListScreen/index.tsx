import React, {useEffect} from 'react';
import {FlatList, View} from 'react-native';
import {usePokemonContext} from '../../../context/PokemonContext';
import ApiPokemonCard from '../../molecules/ApiPokemonCard';
import styles from './styles';

const ApiPokemonListScreen: React.FC = () => {
  const {apiPokemons, fetchApiPokemons} = usePokemonContext();

  useEffect(() => {
    fetchApiPokemons();
  }, []);

  const renderItem = ({item}) => <ApiPokemonCard pokemon={item} />;

  return (
    <View style={styles.container}>
      <FlatList
        data={apiPokemons}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

export default ApiPokemonListScreen;
