import React from 'react';
import {Text, TouchableOpacity, StyleSheet} from 'react-native';

interface SelectorCardProps {
  title: string;
  onPress: () => void;
}

const SelectorCard: React.FC<SelectorCardProps> = ({title, onPress}) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <Text style={styles.title}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    margin: 8,
    borderRadius: 8,
    backgroundColor: '#f9f9f9',
    elevation: 2,
  },
  title: {
    fontSize: 18,
  },
});

export default SelectorCard;
