import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {},
  count: {},
});

export default styles;
