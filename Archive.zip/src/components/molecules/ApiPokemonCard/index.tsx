import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {usePokemonContext} from '../../../context/PokemonContext';
import styles from './styles';
import Pokemon from '../../../models/Pokemon';

const ApiPokemonCard: React.FC<{pokemon: Pokemon}> = ({pokemon}) => {
  const {addApiPokemon} = usePokemonContext();

  const handleAddPokemon = () => {
    addApiPokemon(pokemon);
  };

  return (
    <View style={styles.container}>
      <Text>{pokemon.name}</Text>
      <TouchableOpacity onPress={handleAddPokemon}>
        <Text>Add to Pokedex</Text>
      </TouchableOpacity>
    </View>
  );
};

export default ApiPokemonCard;
