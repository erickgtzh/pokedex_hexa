// AddPokemonScreen.tsx

import React, {useState} from 'react';
import {View, TextInput} from 'react-native';
import {usePokemonContext} from '../../context/PokemonContext';
import {useNavigation} from '@react-navigation/native';
import styles from './styles';
import {colors} from '../../utils/colors';
import Button from '../../components/atoms/Button';

const AddPokemonScreen: React.FC = () => {
  const [name, setName] = useState('');
  const [firstType, setFirstType] = useState('');
  const [firstMove, setFirstMove] = useState('');
  const [lastMove, setLastMove] = useState('');
  const {addPokemon} = usePokemonContext();
  const navigation = useNavigation();

  const handleAddPokemon = () => {
    addPokemon({name, firstType, firstMove, lastMove});
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={name}
        onChangeText={setName}
        placeholderTextColor={colors.grey}
      />
      <TextInput
        style={styles.input}
        placeholder="First Type"
        value={firstType}
        onChangeText={setFirstType}
        placeholderTextColor={colors.grey}
      />
      <TextInput
        style={styles.input}
        placeholder="First Move"
        value={firstMove}
        onChangeText={setFirstMove}
        placeholderTextColor={colors.grey}
      />
      <TextInput
        style={styles.input}
        placeholder="Last Move"
        value={lastMove}
        onChangeText={setLastMove}
        placeholderTextColor={colors.grey}
      />
      <Button
        title="Add Pokemon"
        onPress={handleAddPokemon}
        style={{width: '80%', marginTop: 20}}
      />
    </View>
  );
};

export default AddPokemonScreen;
