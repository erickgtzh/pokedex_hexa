import React from 'react';
import {View, Text} from 'react-native';

const UserProfile: React.FC = () => {
  return (
    <View>
      <Text>User Profile Screen</Text>
    </View>
  );
};

export default UserProfile;
