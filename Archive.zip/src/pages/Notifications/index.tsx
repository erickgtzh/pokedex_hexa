import React from 'react';
import {View, Text} from 'react-native';

const Notifications: React.FC = () => {
  return (
    <View>
      <Text>Add Pokemon Screen</Text>
    </View>
  );
};

export default Notifications;
