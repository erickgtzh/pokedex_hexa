export const BASE_URL = 'https://pokeapi.co/api/v2/';

export const DEFAULT_POKEMON_IMAGE =
  'https://e7.pngegg.com/pngimages/924/387/png-clipart-pikachu-euclidean-ball-open-the-red-ball-wizard-pet-elf.png';
