const colors = {
  primary: '#ABFFAB',

  accent: '#00FF00',

  border: '#dcdcdc',
  error: '#ED4956',

  white: '#FFFFFF',
  black: '#000000',
  grey: '#666666',
  lightgray: '#CCCCCC',
};

export {colors};
